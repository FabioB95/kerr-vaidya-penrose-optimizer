"""
revision.py -- additional computations requested in the refereeing of
CTP-261244 (accretion, general spin law, launch-family dependence, small-alpha
limit at fixed dm).  Usage: python revision.py <group>
groups: accretion | lambda | E0 | smallalpha | neargrid | lambdascan | tablediag | onset
"""
import json, sys, time
import numpy as np
from multiprocessing import Pool
import study as S


def run(args):
    opts = args[-1]
    S.configure(**opts)
    return S.run_case(args[:-1])


if __name__ == "__main__":
    g = sys.argv[1]
    cases = []
    if g == "accretion":            # Reviewer 1: mdot = -alpha > 0
        for law in (0, 1):
            for spin in (0.9, 0.95, 0.99):
                for al in (-1e-4, -1e-3, -1e-2, -1e-1):
                    cases.append((law, spin, al, 1.0, 0.05, 1, {}))
    elif g == "lambda":             # Reviewer 2 (1): spin-down law, lambda = 3
        for spin in (0.9, 0.95, 0.99):
            for al in (1e-4, 1e-3, 1e-2):
                cases.append((2, spin, al, 1.0, 0.05, 1, dict(LAM_=3.0)))
    elif g == "E0":                 # Reviewer 2 (4): launch energy changes the local term
        for E in (0.95, 1.2):
            for spin in (0.9, 0.99):
                cases.append((0, spin, 0.0, 1.0, 0.05, 1, dict(E0_=E)))
            cases.append((1, 0.9, 1e-2, 1.0, 0.05, 1, dict(E0_=E)))
    elif g == "smallalpha":         # Reviewer 2 (3): alpha -> 0 at fixed dm
        for al in (3e-5, 1e-5):
            cases.append((0, 0.95, al, 1.0, 0.045, 1, {}))
            cases.append((1, 0.9, al, 1.0, 0.05, 1, {}))
    elif g == "tablediag":          # Table 1: optima with captured-fragment diagnostics + G distribution
        for law in (0, 1):
            for spin in (0.9, 0.95, 0.99):
                for al in ((0.0,) if law == 0 else ()) + (1e-4, 1e-3, 1e-2, 1e-1):
                    dm = S.dm_for(law, spin)
                    cases.append((law, spin, al, 1.0, dm, 1, {}))
    elif g == "onset":              # dependence on when the episode starts relative to the particle
        for ron in (6.0, 8.0):
            for law in (0, 1):
                for al in (1e-4, 1e-3, 1e-2):
                    cases.append((law, 0.9, al, 1.0, 0.05, 1, dict(R_ON_=ron)))
    elif g == "lambdascan":         # Reviewer 2 (1): bracket of spin-down laws lambda > 2
        for lam in (2.5, 4.0, 6.0):
            for spin in (0.9, 0.99):
                for al in (1e-4, 1e-3, 1e-2):
                    cases.append((2, spin, al, 1.0, 0.05, 1, dict(LAM_=lam)))
    elif g == "neargrid":           # Reviewer 2 (3): resolve decays closer to r_+ at small alpha
        ext = [1e-6, 3e-6, 1e-5, 3e-5, 1e-4, 3e-4]
        for al in (1e-4, 3e-5, 1e-5):
            cases.append((0, 0.95, al, 1.0, 0.045, 1, dict(D_EXTRA_=ext)))
        cases.append((0, 0.95, 0.0, 1.0, 0.045, 1, dict(D_EXTRA_=ext)))
    t0 = time.time()
    with Pool(2) as pool:
        res = pool.map(run, cases, chunksize=1)
    print("elapsed", time.time() - t0)
    json.dump(res, open(f"../data/rev_{g}.json", "w"), indent=1, default=float)
    if g == "tablediag":            # flat list of the optima used by make_tables.py, fixedtraj.py, uvcheck.py
        flat = []
        for R in res:
            if R['best'] is not None:
                b = dict(R['best']); b.update(law=R['law'], spin=R['spin'], alpha=R['alpha'], dm=R['dm'])
                flat.append(b)
        json.dump(flat, open("../data/rev_table_diag.json", "w"), indent=1, default=float)
    for R in res:
        b = R['best']
        if b is None:
            print(R['law'], R['spin'], R['alpha'], 'none'); continue
        print(f"law={R['law']} a={R['spin']} al={R['alpha']:.0e} E0={R['E0']} lam={R['lam']} a/m_s={b['a_s']/b['m_s']:.4f} "
              f"G={b['G']:.4f} in={b['T_in']:.4f} loc={b['loc']:.4f} out={b['T_out']:.4f} "
              f"E2H={b.get('E2H',np.nan):.4f} chi={b.get('E2H_chi',np.nan):.4f} vres3={b.get('vres3',0):.0f} viol={R['max_bound_violation']:.1e}")
