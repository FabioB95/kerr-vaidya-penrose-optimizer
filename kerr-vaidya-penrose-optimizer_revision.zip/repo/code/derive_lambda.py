"""derive_lambda.py -- symbolic check of the transport law for the general
spin law dJ/dm = lambda a, i.e. a = a0 (m/M)^(lambda-1), adot = (lambda-1)(a/m) mdot,
on the equator (revision of CTP-261244, Reviewer 2 point 1):

  dE/dtau = -mdot [ p_r^2/r - (lambda-1)(a/m)(p_v+p_r) p^phi ],
  p^phi = (a p_v + a p_r + p_phi)/r^2 .
Valid for either sign of mdot (mass loss or accretion)."""
import sympy as sp
r, m, a = sp.symbols('r m a', positive=True)
pv, pr, pph, lam, mdot = sp.symbols('p_v p_r p_phi lambda mdot', real=True)
D = r**2 - 2*m*r + a**2
# equatorial Hamiltonian 2H = g^{mu nu} p_mu p_nu
H2 = (a**2*pv**2 + 2*(r**2 + a**2)*pv*pr + 2*a*pv*pph + D*pr**2 + 2*a*pr*pph + pph**2) / r**2
H = H2 / 2
adot = (lam - 1) * a / m * mdot
dEdtau = sp.diff(H, m)*mdot + sp.diff(H, a)*adot        # dE/dtau = -dp_v/dtau = +dH/dv
pphi_up = (a*pv + a*pr + pph) / r**2
claim = -mdot*(pr**2/r - (lam - 1)*(a/m)*(pv + pr)*pphi_up)
print('difference (should be 0):', sp.simplify(dEdtau - claim))
