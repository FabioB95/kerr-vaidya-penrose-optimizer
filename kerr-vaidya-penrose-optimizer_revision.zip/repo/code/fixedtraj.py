"""
fixedtraj.py -- Reviewer 2 (3): transport terms along a FIXED decay
configuration (L0, delta, psi) as alpha -> 0 at fixed dm.  For a fixed
configuration the residence time stays finite and the transport terms vanish
as alpha [times a logarithm for the escaping fragment, whose read-out radius
grows as dm/alpha]; the optimum over configurations is not uniform in alpha.
"""
import json
import numpy as np
import study as S

d = json.load(open('../data/rev_table_diag.json'))
pick = {(x['law'], x['spin'], x['alpha']): x for x in d}
out = []
for key, dm in (((0, 0.9, 0.0), 0.05), ((1, 0.9, 1e-3), 0.05), ((0, 0.95, 1e-4), 0.045)):
    b = pick[key]
    law, spin = key[0], key[1]
    for al in (1e-1, 3e-2, 1e-2, 3e-3, 1e-3, 3e-4, 1e-4, 3e-5, 1e-5, 3e-6, 1e-6):
        x = S.evaluate_full(law, spin, al, dm, 1.0, b['L0'], b['delta'], b['psi'])
        row = dict(source=list(key), law=law, spin=spin, alpha=al, dm=dm)
        if x is None:
            row['valid'] = False
        else:
            row.update(valid=True, G=x['G'], T_in=x['T_in'], loc=x['loc'], T_out=x['T_out'],
                       E3s=x['E3s'], r_s=x['r_s'])
        out.append(row)
        print(row)
json.dump(out, open('../data/rev_fixedtraj.json', 'w'), indent=1, default=float)
