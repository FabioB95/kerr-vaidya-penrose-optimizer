"""
viability_full.py -- Reviewer 2 (5): ergosphere ACCESSIBILITY versus full
EXTRACTION viability for law A.

The mass decreases linearly from M = 1 and the episode stops when the hole
becomes (numerically) extremal, dm = (1 - a) - 1e-7, i.e. at v_ext.  Law A
cannot be continued beyond this point without destroying the horizon.

accessible(alpha): some parent of the launch family enters the instantaneous
    ergosphere, outside r_+(v), before v_ext (necessary condition, Cor. 1).
viable(alpha): some decay of the launch family (L0 grid x delta grid x psi
    grid) at v_s < v_ext has E2 < 0, fragment 2 is captured (crosses the
    horizon and never re-emerges) and fragment 3 escapes to r > 200 M.
Usage: python viability_full.py [E0] [R_ON]
"""
import json, sys
import numpy as np
from multiprocessing import Pool
import kvcore as K

R0, R_FAR = 10.0, 200.0
E0 = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
RON = float(sys.argv[2]) if len(sys.argv) > 2 else 3.0
L_grid = np.linspace(-4.0, 4.5, 69)
D_grid = np.array([0.001, 0.003, 0.01, 0.02, 0.04, 0.07, 0.1, 0.15, 0.2, 0.28, 0.36, 0.45, 0.55, 0.7])
PSI = np.linspace(-np.pi, np.pi, 145)[:-1]
DEPTH = 1e-3


def onset(a, L0):
    Pst = K.mkpar(0, 0.0, 1.0, a)
    pr0 = K.pr_from_shell(R0, 1.0, a, -E0, L0, 1.0, 'in')
    if pr0 is None:
        return None
    y0 = np.array([0.0, R0, 0.0, -E0, pr0, L0])
    yon, _, st0, _, _, _ = K.integrate(y0, Pst, 1e5, 1e4, 2, RON)
    return yon if st0 == K.EVENT else None


def accessible(a, alpha):
    dm = (1.0 - a) - 1e-7
    for L0 in L_grid:
        yon = onset(a, L0)
        if yon is None:
            continue
        P = K.mkpar(0, alpha, dm, a, yon[0])
        vext = yon[0] + dm / alpha if alpha > 0 else np.inf
        ys, _, st, _, _, _ = K.integrate(yon, P, 1e5, 1e4, 3, -DEPTH)
        if st != K.EVENT or ys[0] >= vext:
            continue
        m, aa, _, _ = K.mass_state(ys[0], P)
        if ys[1] > K.r_plus(m, aa):
            return True
    return False


def viable_L(args):
    a, alpha, L0 = args
    dm = (1.0 - a) - 1e-7
    yon = onset(a, L0)
    if yon is None:
        return None
    P = K.mkpar(0, alpha, dm, a, yon[0])
    vext = yon[0] + dm / alpha if alpha > 0 else np.inf
    best = None
    for d in D_grid:
        ys, _, st, _, _, _ = K.integrate(yon, P, 1e5, R_FAR, 1, d)
        if st != K.EVENT or ys[0] >= vext:
            continue
        m, aa, _, _ = K.mass_state(ys[0], P)
        if ys[1] >= 2 * m:
            continue
        for psi in PSI:
            p2, p3 = K.decay(ys, P, 1.0, psi)
            if -p2[0] <= 0 and p2[0] < 0:
                pass
            if -p2[0] >= 0:          # E2 >= 0
                continue
            f2, _, s2, _, _, _ = K.integrate(np.concatenate([ys[:3], p2]), P, 1e6, R_FAR, 0, 0.0)
            if s2 != K.CAPTURED:
                continue
            f3, _, s3, _, _, _ = K.integrate(np.concatenate([ys[:3], p3]), P, 1e6, R_FAR, 0, 0.0)
            if s3 != K.ESCAPED:
                continue
            G = -f3[3] - E0
            if best is None or G > best[0]:
                best = (G, L0, d, psi, ys[0] - yon[0])
    return best


def viable(a, alpha, pool):
    res = pool.map(viable_L, [(a, alpha, L) for L in L_grid], chunksize=2)
    res = [r for r in res if r is not None]
    return max(res) if res else None


def bisect(test, lo=1e-4, hi=1.0, tol=1.01):
    """largest alpha with test(alpha) True; test(lo) must be True"""
    if not test(lo):
        return None
    if test(hi):
        return hi
    while hi / lo > tol:
        mid = np.sqrt(lo * hi)
        if test(mid):
            lo = mid
        else:
            hi = mid
    return lo


if __name__ == "__main__":
    spins = (0.8, 0.85, 0.9, 0.95, 0.98, 0.99) if (E0 == 1.0 and RON == 3.0) else (0.8, 0.9, 0.99)
    out = []
    with Pool(2) as pool:
        for a in spins:
            acc = bisect(lambda al: accessible(a, al))
            via = bisect(lambda al: viable(a, al, pool) is not None)
            bv = viable(a, 0.97 * via, pool) if via else None
            row = dict(a=a, E0=E0, R_ON=RON, alpha_acc=acc, alpha_viab=via,
                       G_near_boundary=None if bv is None else bv[0])
            out.append(row)
            print(row, flush=True)
    json.dump(out, open(f'../data/rev_viability_full_E{E0}_R{RON}.json', 'w'), indent=1, default=float)
