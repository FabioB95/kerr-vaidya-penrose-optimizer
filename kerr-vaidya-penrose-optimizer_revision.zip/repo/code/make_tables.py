"""make_tables.py -- LaTeX rows of Tables 1 and 2 of the revised manuscript from the JSON data."""
import json, sys
D = '../data/'
OUT = "../data/"
def ex(a):
    if a == 0: return '0'
    s = '-' if a < 0 else ''
    import math
    e = int(round(math.log10(abs(a))))
    return f'${s}10^{{{e}}}$'
def f3(x): 
    s = f'{x:.3f}'
    return '0.000' if s == '-0.000' else s
# ---- Table 1 (main budget)
rows = json.load(open(D + 'rev_table_diag.json'))
import numpy as np
med = {(R['law'], R['spin'], R['alpha']): float(np.median(R['G_all']))
       for R in json.load(open(D + 'rev_tablediag.json'))}
key = lambda r: (r['law'], r['spin'], r['alpha'])
order = []
for law in (0, 1):
    for spin in (0.9, 0.95, 0.99):
        for al in ((0.0,) if law == 0 else ()) + (1e-4, 1e-3, 1e-2, 1e-1):
            order.append((law, spin, al))
R = {key(r): r for r in rows}
lines = []
for i, k in enumerate(order):
    r = R[k]
    law = '--' if k[2] == 0 else 'AB'[k[0]]
    if i > 0 and k[0] == 1 and order[i-1][0] == 0:
        lines.append(r'\midrule')
    lines.append(f"{law} & {k[1]} & {ex(k[2])} & {r['a_s']/r['m_s']:.3f} & {f3(r['T_in'])} & {f3(r['loc'])} & "
                 f"\\rev{{{f3(-r['E2H'])}}} & \\rev{{{r['L2']:.3f}}} & {f3(r['T_out'])} & {f3(r['G'])} & \\rev{{{f3(med[k])}}} \\\\")
open(OUT + 'table_budget.tex', 'w').write('\n'.join(lines) + '\n')
# ---- Table 2 (accretion and spin-down law)
acc = json.load(open(D + 'rev_accretion.json'))
lam = json.load(open(D + 'rev_lambda.json'))
lines = []
for R_ in sorted(acc, key=lambda R: (R['law'], R['spin'], -R['alpha'])):
    b = R_['best']
    lines.append(f"{'AB'[R_['law']]}, $\\dot m>0$ & {R_['spin']} & {ex(-R_['alpha'])} & {b['a_s']/b['m_s']:.3f} & "
                 f"{f3(b['T_in'])} & {f3(b['loc'])} & {f3(-b['E2H'])} & {f3(b['T_out'])} & {f3(b['G'])} \\\\")
lines.append(r'\midrule')
for R_ in sorted(lam, key=lambda R: (R['spin'], R['alpha'])):
    b = R_['best']
    lines.append(f"$\\lambda=3$ & {R_['spin']} & {ex(-R_['alpha'])} & {b['a_s']/b['m_s']:.3f} & "
                 f"{f3(b['T_in'])} & {f3(b['loc'])} & {f3(-b['E2H'])} & {f3(b['T_out'])} & {f3(b['G'])} \\\\")
open(OUT + 'table_laws.tex', 'w').write('\n'.join(lines) + '\n')
print(open(OUT + 'table_budget.tex').read()); print(open(OUT + 'table_laws.tex').read())
