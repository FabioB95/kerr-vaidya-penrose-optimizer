"""
nonuniform.py -- Reviewer 2 (3): the limit alpha -> 0 at fixed dm is not
uniform.  For each alpha we bisect the angular momentum L0 of a scattering
geodesic (law A, a = 0.9, E0 = 1.1, start r = 50M, episode of dm = 0.05
starting at r = 6M inbound) between a captured and an escaping orbit IN THE
DYNAMIC SPACETIME.  Orbits on the escaping side of the boundary whirl around
the (moving) unstable circular orbit for a time that grows as the boundary is
approached, and experience a growing fraction of the whole mass loss dm.
We record, for each bisection depth, the energy gain Delta E = E_inf - E0, the
advanced time spent inside r < 10M and the mass lost during that time.
"""
import json
import numpy as np
import kvcore as K

E0, R0, RON, DM, A = 1.1, 50.0, 6.0, 0.05, 0.9


def run(L0, alpha):
    Pst = K.mkpar(0, 0.0, DM, A)
    pr0 = K.pr_from_shell(R0, 1.0, A, -E0, L0, 1.0, 'in')
    y0 = np.array([0.0, R0, 0.0, -E0, pr0, L0])
    yon, _, st, _, _, _ = K.integrate(y0, Pst, 1e6, 1e9, 2, RON)
    P = K.mkpar(0, alpha, DM, A, yon[0])
    yf, _, stf, _, tr, nt = K.integrate(yon, P, 1e7, 400.0, 0, 0.0, record=2_000_000)
    tr = tr[:nt]
    ins = tr[:, 1] < 10.0
    vin = tr[ins, 0]
    tres = vin.max() - vin.min() if ins.any() else 0.0
    m_a = K.mass_state(vin.min(), P)[0] if ins.any() else 1.0
    m_b = K.mass_state(vin.max(), P)[0] if ins.any() else 1.0
    return stf, (-yf[3] - E0), tres, m_a - m_b


if __name__ == "__main__":
    out = []
    for alpha in (1e-2, 3e-3, 1e-3, 3e-4, 1e-4):
        # bracket: scan L0 for a captured / escaped pair
        Ls = np.linspace(2.6, 3.4, 81)
        sts = [run(L, alpha)[0] for L in Ls]
        lo = hi = None
        for i in range(len(Ls) - 1):
            if sts[i] == K.CAPTURED and sts[i + 1] == K.ESCAPED:
                lo, hi = Ls[i], Ls[i + 1]
                break
        rows = []
        for it in range(60):
            mid = 0.5 * (lo + hi)
            if mid == lo or mid == hi:
                break
            st, dE, tres, dmexp = run(mid, alpha)
            if st == K.ESCAPED:
                hi = mid
                rows.append(dict(depth=it, L0=mid, dE=dE, v_res=tres, dm_exp=dmexp))
            elif st == K.CAPTURED:
                lo = mid
            else:
                break
        best = max(rows, key=lambda r: r['dE'])
        generic = run(3.3, alpha)
        res = dict(alpha=alpha, L_crit=0.5 * (lo + hi), generic_dE=generic[1], generic_vres=generic[2],
                   best=best, rows=rows)
        out.append(res)
        print(f"alpha={alpha:.0e}: generic dE={generic[1]:.2e} (v_res={generic[2]:.0f}) | "
              f"tuned: max dE={best['dE']:.4f}, v_res={best['v_res']:.0f}, dm_exp={best['dm_exp']:.4f}, "
              f"dE/dm_exp={best['dE']/max(best['dm_exp'],1e-12):.2f}, depth={best['depth']}, |L-Lc|~{hi-lo:.1e}",
              flush=True)
    json.dump(out, open('../data/rev_nonuniform.json', 'w'), indent=1, default=float)
