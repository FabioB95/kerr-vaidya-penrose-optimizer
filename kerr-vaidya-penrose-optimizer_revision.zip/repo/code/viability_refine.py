"""
viability_refine.py -- Reviewer 2 (5): accuracy of alpha_viab.  The bisection of
viability_full.py uses a grid (69 L0 x 14 delta x 144 psi) without continuous
refinement, so it gives a lower bound.  Here we test rates ABOVE the computed
alpha_viab with a grid twice as fine in L0, delta and three times in psi
(137 x 27 x 432): if no complete extraction is found there, the extraction
boundary of the family lies between alpha_viab and the tested rate.
Usage: python viability_refine.py <factor> <spins...>
"""
import json, sys
import numpy as np
from multiprocessing import Pool
import viability_full as V

V.L_grid = np.linspace(-4.0, 4.5, 137)
d0 = V.D_grid
V.D_grid = np.unique(np.concatenate([d0, np.sqrt(d0[1:] * d0[:-1])]))
V.PSI = np.linspace(-np.pi, np.pi, 433)[:-1]

if __name__ == "__main__":
    fac = float(sys.argv[1])
    spins = [float(x) for x in sys.argv[2:]]
    base = {r['a']: r for r in json.load(open('../data/rev_viability_full_E1.0_R3.0.json'))}
    out = []
    with Pool(2) as pool:
        for a in spins:
            al = fac * base[a]['alpha_viab']
            res = pool.map(V.viable_L, [(a, al, L) for L in V.L_grid], chunksize=4)
            res = [r for r in res if r is not None]
            row = dict(a=a, alpha_viab=base[a]['alpha_viab'], factor=fac, alpha_test=al,
                       found=bool(res), best=max(res) if res else None)
            out.append(row); print(row, flush=True)
    json.dump(out, open(f'../data/rev_viability_refine_{fac}.json', 'w'), indent=1, default=float)
