"""derive_offeq.py -- symbolic check of the full (all theta) inverse of the
ingoing Kerr--Vaidya metric used by offeq.py."""
import sympy as sp
r, th, m, a = sp.symbols('r theta m a', positive=True)
S = r**2 + a**2*sp.cos(th)**2
D = r**2 - 2*m*r + a**2
s2 = sp.sin(th)**2
g = sp.zeros(4, 4)            # (v, r, theta, phi)
g[0, 0] = -(1 - 2*m*r/S); g[0, 1] = g[1, 0] = 1
g[0, 3] = g[3, 0] = -2*a*m*r*s2/S; g[1, 3] = g[3, 1] = -a*s2
g[2, 2] = S; g[3, 3] = ((r**2 + a**2)**2 - D*a**2*s2)*s2/S
gi = sp.zeros(4, 4)
gi[0, 0] = a**2*s2/S; gi[0, 1] = gi[1, 0] = (r**2 + a**2)/S; gi[0, 3] = gi[3, 0] = a/S
gi[1, 1] = D/S; gi[1, 3] = gi[3, 1] = a/S; gi[2, 2] = 1/S; gi[3, 3] = 1/(S*s2)
print('g * ginv - 1 =', sp.simplify(g*gi - sp.eye(4)))
