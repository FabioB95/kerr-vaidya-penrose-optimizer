"""
uvcheck.py -- checks of the assumptions of Proposition 3:
 (a) u^v > 0 along the parent and both fragments of every optimal decay of Table 1;
 (b) u^v >= u_* > 0 and T = (r/Sigma) p_r^2 / u^v >= T_* > 0 along the tuned
     scattering orbits of Table 3 (nonuniform.py), while they reside near the hole.
"""
import json
import numpy as np
import kvcore as K
import nonuniform as NU

out = {}
# (a)
d = json.load(open('../data/rev_table_diag.json'))
worst = np.inf
for b in d:
    law, spin, al, dm = b['law'], b['spin'], b['alpha'], b['dm']
    Pst = K.mkpar(law, 0.0, dm, spin)
    pr0 = K.pr_from_shell(10.0, 1.0, spin, -1.0, b['L0'], 1.0, 'in')
    y0 = np.array([0, 10.0, 0, -1.0, pr0, b['L0']])
    yon, _, _, _, _, _ = K.integrate(y0, Pst, 1e5, 200, 2, 3.0)
    P = K.mkpar(law, al, dm, spin, yon[0])
    ys, _, _, _, t1, n1 = K.integrate(yon, P, 1e5, 200, 1, b['delta'], record=200000)
    p2, p3 = K.decay(ys, P, 1.0, b['psi'])
    trs = [t1[:n1]]
    for p in (p2, p3):
        _, _, _, _, t, n = K.integrate(np.concatenate([ys[:3], p]), P, 1e6, 200, 0, 0.0, record=400000)
        trs.append(t[:n])
    f = np.empty(6)
    for tr in trs:
        for row in tr:
            K.rhs(row[:6], P, f)
            worst = min(worst, f[0])
out['min_uv_table1'] = float(worst)
print('(a) min u^v over Table-1 optima:', worst)
# (b)
res = json.load(open('../data/rev_nonuniform.json'))
rows = []
for R in res:
    alpha, L0 = R['alpha'], R['best']['L0']
    Pst = K.mkpar(0, 0.0, NU.DM, NU.A)
    pr0 = K.pr_from_shell(NU.R0, 1.0, NU.A, -NU.E0, L0, 1.0, 'in')
    y0 = np.array([0.0, NU.R0, 0.0, -NU.E0, pr0, L0])
    yon, _, _, _, _, _ = K.integrate(y0, Pst, 1e6, 1e9, 2, NU.RON)
    P = K.mkpar(0, alpha, NU.DM, NU.A, yon[0])
    _, _, _, _, tr, nt = K.integrate(yon, P, 1e7, 400.0, 0, 0.0, record=2_000_000)
    tr = tr[:nt]
    f = np.empty(6)
    uv = []; T = []
    for row in tr:
        if row[1] < 10.0:
            K.rhs(row[:6], P, f)
            uv.append(f[0]); T.append(row[4] ** 2 / row[1] / f[0])
    rows.append(dict(alpha=alpha, min_uv=float(min(uv)), min_T=float(min(T)), median_T=float(np.median(T))))
    print('(b)', rows[-1])
out['tuned'] = rows
json.dump(out, open('../data/rev_uvcheck.json', 'w'), indent=1)
