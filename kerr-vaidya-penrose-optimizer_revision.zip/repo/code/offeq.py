"""
offeq.py -- Reviewer 2 (5): ergosphere accessibility for NON-EQUATORIAL
incoming families (law A, linear mass loss until extremality).

Full ingoing Kerr--Vaidya Hamiltonian in (v, r, theta, phi); the inverse metric
is verified in derive_offeq.py.  The mass changes only g^{rr} = Delta/Sigma, so
dp_v/dtau = mdot r p_r^2 / Sigma (Proposition 2 at all theta).
A family: E0 = 1, launch at r0 = 10M on the equator with p_theta = q (Carter
constant Q = q^2 at launch), L0 on a grid; episode onset when r = 3M.
alpha_acc: largest alpha for which some member enters the instantaneous
ergosphere r < m + sqrt(m^2 - a^2 cos^2 theta), outside r_+(v), before v_ext.
"""
import json, sys
import numpy as np
from numba import njit
from scipy.integrate import solve_ivp

R0, RON, E0, DEPTH = 10.0, 3.0, 1.0, 1e-3


@njit(cache=True)
def mstate(v, alpha, a, von):
    if alpha <= 0.0 or v <= von:
        return 1.0, 0.0
    m = 1.0 - alpha * (v - von)
    if m <= a:
        return a, 0.0
    return m, -alpha


@njit(cache=True)
def rhs(t, y, alpha, a, von):
    v, r, th, ph, pv, pr, pt, pp = y
    m, md = mstate(v, alpha, a, von)
    s = np.sin(th); c = np.cos(th); s2 = s * s
    S = r * r + a * a * c * c
    D = r * r - 2 * m * r + a * a
    N = (a * a * s2 * pv * pv + 2 * (r * r + a * a) * pv * pr + 2 * a * pv * pp
         + D * pr * pr + 2 * a * pr * pp + pt * pt + pp * pp / s2)
    out = np.empty(8)
    out[0] = (a * a * s2 * pv + (r * r + a * a) * pr + a * pp) / S
    out[1] = ((r * r + a * a) * pv + D * pr + a * pp) / S
    out[2] = pt / S
    out[3] = (a * pv + a * pr + pp / s2) / S
    out[4] = md * r * pr * pr / S
    Nr = 4 * r * pv * pr + (2 * r - 2 * m) * pr * pr
    out[5] = -(Nr / (2 * S) - N * 2 * r / (2 * S * S))
    Nt = 2 * a * a * s * c * pv * pv - 2 * c * pp * pp / (s2 * s)
    St = -2 * a * a * s * c
    out[6] = -(Nt / (2 * S) - N * St / (2 * S * S))
    out[7] = 0.0
    return out


def pr_in(r, th, a, pv, pt, pp):
    s2 = np.sin(th) ** 2; S = r * r + a * a * np.cos(th) ** 2
    D = r * r - 2 * r + a * a
    A = D; B = 2 * ((r * r + a * a) * pv + a * pp)
    C = a * a * s2 * pv * pv + 2 * a * pv * pp + pt * pt + pp * pp / s2 + S
    disc = B * B - 4 * A * C
    if disc < 0:
        return None
    for prr in ((-B - np.sqrt(disc)) / (2 * A), (-B + np.sqrt(disc)) / (2 * A)):
        drdt = ((r * r + a * a) * pv + D * prr + a * pp) / S
        dvdt = (a * a * s2 * pv + (r * r + a * a) * prr + a * pp) / S
        if drdt < 0 and dvdt > 0:
            return prr
    return None


def onset(a, L0, q):
    pr = pr_in(R0, np.pi / 2, a, -E0, q, L0)
    if pr is None:
        return None
    y0 = np.array([0.0, R0, np.pi / 2, 0.0, -E0, pr, q, L0])
    ev = lambda t, y, *p: y[1] - RON
    ev.terminal = True; ev.direction = -1
    cap = lambda t, y, *p: y[1] - 1.0 - np.sqrt(max(1 - a * a, 0)) - 1e-3
    cap.terminal = True
    sol = solve_ivp(rhs, (0, 2e3), y0, args=(0.0, a, 0.0), events=(ev, cap), rtol=1e-10, atol=1e-12,
                    method='DOP853')
    if sol.status == 1 and len(sol.t_events[0]):
        return sol.y_events[0][0]
    return None


def enters(a, alpha, yon):
    von = yon[0]
    dm = 1.0 - a
    vext = von + dm / alpha if alpha > 0 else np.inf

    def ergo(t, y, *p):
        m, _ = mstate(y[0], alpha, a, von)
        return y[1] - (m + np.sqrt(max(m * m - a * a * np.cos(y[2]) ** 2, 0.0))) + DEPTH
    ergo.terminal = True; ergo.direction = -1

    def late(t, y, *p):
        return vext - y[0]
    late.terminal = True
    sol = solve_ivp(rhs, (0, 1e3), yon, args=(alpha, a, von), events=(ergo, late), rtol=1e-10,
                    atol=1e-12, method='DOP853')
    if len(sol.t_events[0]):
        y = sol.y_events[0][0]
        m, _ = mstate(y[0], alpha, a, von)
        rp = m + np.sqrt(max(m * m - a * a, 0.0))
        return y[0] < vext and y[1] > rp, y[0] - von, y[2]
    return False, None, None


def alpha_acc(a, q, Lg):
    starts = [s for s in (onset(a, L, q) for L in Lg) if s is not None]
    dv0 = [d for ok, d, _ in (enters(a, 0.0, s) for s in starts) if ok]
    test = lambda al: any(enters(a, al, s)[0] for s in starts)
    lo, hi = 1e-4, 1.0
    if not test(lo):
        return None, None, len(starts)
    while hi / lo > 1.01:
        mid = np.sqrt(lo * hi)
        if test(mid):
            lo = mid
        else:
            hi = mid
    return lo, min(dv0) if dv0 else None, len(starts)


if __name__ == "__main__":
    Lg = np.linspace(-4.0, 4.5, 35)
    out = []
    qs = [float(x) for x in sys.argv[1:]] or [0.0, 2.0, 4.0]
    for q in qs:
        for a in (0.8, 0.9, 0.99):
            acc, dv, n = alpha_acc(a, q, Lg)
            row = dict(a=a, p_theta0=q, alpha_acc=acc, dv_min=dv, n_family=n,
                       pred=None if dv is None else (1 - a) / dv)
            out.append(row); print(row, flush=True)
    json.dump(out, open('../data/rev_offeq_access_' + '_'.join(str(q) for q in qs) + '.json', 'w'), indent=1, default=float)
