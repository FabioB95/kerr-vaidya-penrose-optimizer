"""
viability_scan.py -- Reviewer 2 (5): the bisection of viability_full.py assumes
that the viable rates form an interval.  Here we scan a logarithmic grid of
rates between 1.05 alpha_viab and alpha_acc with the same search, to check that
no complete extraction exists above alpha_viab.
"""
import json
import numpy as np
from multiprocessing import Pool
import viability_full as V

if __name__ == "__main__":
    base = json.load(open('../data/rev_viability_full_E1.0_R3.0.json'))
    out = []
    with Pool(2) as pool:
        for r in [b for b in base if b['a'] in (0.8, 0.9, 0.99)]:
            al_grid = np.geomspace(1.05 * r['alpha_viab'], r['alpha_acc'], 6)
            found = []
            for al in al_grid:
                if V.viable(r['a'], al, pool) is not None:
                    found.append(float(al))
            row = dict(a=r['a'], alpha_viab=r['alpha_viab'], alpha_acc=r['alpha_acc'],
                       tested=[float(x) for x in al_grid], viable_above=found)
            out.append(row); print(row, flush=True)
    json.dump(out, open('../data/rev_viability_scan.json', 'w'), indent=1)
