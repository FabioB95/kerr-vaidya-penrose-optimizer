# Penrose process in radiating Kerr–Vaidya black holes

Code and data for the paper

> **Penrose process in radiating Kerr–Vaidya black holes: efficiency, energy transport, and the viability boundary**
> F. Buffoli, *Communications in Theoretical Physics* (manuscript CTP-261244, revised version)

The code integrates equatorial geodesics in the ingoing Kerr–Vaidya metric, performs Penrose decays with **exact four-momentum conservation**, and searches for the decay that maximises the net energy gain of the escaping fragment. It decomposes the gain into transport before the decay, the local decay term and transport after the decay, and computes the ergosphere-accessibility and extraction-viability boundaries.

## Main results

- **Decay bound (Proposition 1).** The local efficiency is bounded by the instantaneous Kerr value; the bound reduces to the Bardeen–Press–Teukolsky efficiency at the horizon. No integrated decay violates it (largest excess 8×10⁻⁸, at the integration tolerance).
- **Exact transport law (Proposition 2).** For fixed `a`, `dE/dτ = −ṁ (r/Σ) p_r²` along every geodesic, for either sign of `ṁ`. For the general spin law `dJ/dm = λ a` there is an extra term `+ṁ (λ−1)(a/m)(p_v+p_r) p^φ` on the equator.
- **Size of the transport terms (Proposition 3).** `ΔE = ∫ T |dm|` is bounded by `δm · sup T`, uniformly in the rate. For a fixed trajectory it is `O(α)` (plus a logarithmic far-field tail `O(α ln α⁻¹)`), but **not uniformly** over decay configurations.
- **Captured fragment.** The energy `E_2H` and angular momentum `L_2` at the crossing of `r_+(v)` satisfy `E_2H − Ω_H L_2 ≥ 0`. In all the optima, `|E_2H − E_2s| ≤ 5×10⁻⁴`.
- **Spin laws and accretion.** Mass loss at fixed or growing `a/m` (laws A, B) enhances the net gain through transport. Accretion and the spin-down law `λ = 3` give gains **below** the static optimum.
- **Boundaries (law A).** The hole reaches extremality during the episode. Ergosphere accessibility requires `α < α_acc ≃ (M−a)/Δv`. Complete extraction (negative-energy capture and escape) requires `α < α_viab ≈ α_acc / 3`. Both boundaries depend on the incoming-trajectory family.

## Repository structure

```
code/
  kvcore.py            core: metric, Hamilton's equations, mass/spin laws (A, B, general λ,
                       accretion), adaptive Dormand–Prince 5(4) integrator with event location,
                       exact decay kinematics, horizon-crossing diagnostics
  study.py             Penrose search (grid + Nelder–Mead), energy budget, diagnostics
  revision.py          additional runs of the revision: accretion, λ = 3, launch energy E0,
                       small α, extended decay grid
  fixedtraj.py         fixed decay configurations versus α (fine-tuning test)
  viability.py         ergosphere-accessibility boundary (original version)
  viability_full.py    accessibility AND full extraction-viability boundaries, any E0 / onset radius
  viability_refine.py  finer-grid test above alpha_viab (brackets the extraction boundary)
  offeq.py             accessibility boundary for NON-equatorial parents (full theta Hamiltonian)
  nonuniform.py        orbits tuned to the capture/escape boundary: non-uniform alpha -> 0 limit
  flyby.py             pure transport on scattering orbits (first-order and impulsive limits)
  validate.py          validation suite (Hamilton equations, identities, conservation, BPT limit)
  derive_identities.py, derive_lawB.py, derive_lambda.py, derive_offeq.py, derive_kn.py
                       symbolic (SymPy) derivations of the metric identities and transport laws
  kn_test.py, vaidya_test.py, bench.py, old_crit_check.py   auxiliary tests
  make_figures.py      all figures of the paper
data/                  JSON/TXT output of every script (rev_* = revision runs)
figures/               figures of the paper (PDF)
```

## Installation

```bash
git clone https://github.com/FabioB95/kerr-vaidya-penrose-optimizer.git
cd kerr-vaidya-penrose-optimizer
pip install -r requirements.txt
```

Requirements: Python ≥ 3.9, NumPy, SciPy, Numba, SymPy, Matplotlib.

## Reproducing the paper

All scripts are run from `code/`:

```bash
cd code
python validate.py                     # validation suite -> data/validation.txt
python study.py all                    # main energy budget (Table 1, Figs. 1, 3, 5)
python study.py conv                   # convergence tests (Appendix)
python flyby.py                        # Fig. 2
python revision.py accretion           # Table 2, accretion (Sec. V.E)
python revision.py lambda              # Table 2, spin-down law λ = 3 (Sec. V.F)
python revision.py E0                  # dependence of the local term on the launch energy
python revision.py smallalpha          # slow limit at fixed δm
python revision.py neargrid            # extended decay grid down to δ = 1e-6 M
python revision.py lambdascan          # spin-down bracket λ = 2.5, 4, 6 (Table 4)
python nonuniform.py                   # tuned orbits, non-uniform limit (Table 3)
python fixedtraj.py                    # fine tuning of the optima
python viability_full.py 1.0 3.0       # α_acc and α_viab, E0 = 1, onset r = 3M (Fig. 6)
python viability_full.py 1.2 3.0       # other incoming families
python viability_full.py 1.0 6.0
python viability_refine.py 1.05 0.8 0.9 0.99   # boundary bracket
python offeq.py 0 2 4 && python offeq.py 1 3   # inclined families
python make_figures.py                 # all figures
```

Parameter arrays use `kvcore.mkpar(law, alpha, dm, spin, v_on, lam)`, with `law = 0` (fixed `a`), `1` (fixed `a/m`) or `2` (general `λ`). Use `alpha > 0` for mass loss and `alpha < 0` for accretion.

Units: G = c = 1, initial mass M = 1; energies per unit rest mass of the incoming particle.

## Citation

```bibtex
@article{buffoli_kvpenrose,
  author  = {Buffoli, Fabio},
  title   = {Penrose process in radiating {Kerr--Vaidya} black holes: efficiency,
             energy transport, and the viability boundary},
  journal = {Communications in Theoretical Physics},
  note    = {under review},
  year    = {2026}
}
```

## License

MIT License, see `LICENSE`.

## Contact

Fabio Buffoli, Università degli Studi di Brescia — fabio.buffoli@unibs.it
